module.exports = {
    googleClientId:"224215270537-dtgav02548e8bbrlbltujslkf9c504o9.apps.googleusercontent.com",
    googleClientSecret:"s-bL9J8Vw92-c50y5jZoDoyu",
}